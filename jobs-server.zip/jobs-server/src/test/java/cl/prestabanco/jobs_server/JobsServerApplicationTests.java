package cl.prestabanco.jobs_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobsServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
