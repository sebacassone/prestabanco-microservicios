package cl.prestabanco.jobs_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobsServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobsServerApplication.class, args);
	}

}
