package cl.prestabanco.documents_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentsServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentsServerApplication.class, args);
	}

}
