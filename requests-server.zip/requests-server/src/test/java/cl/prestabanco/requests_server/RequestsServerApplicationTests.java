package cl.prestabanco.requests_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestsServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
