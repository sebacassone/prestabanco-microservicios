package cl.prestabanco.addresses_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddressesServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddressesServerApplication.class, args);
	}

}
