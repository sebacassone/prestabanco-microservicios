package cl.prestabanco.addresses_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressesServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
