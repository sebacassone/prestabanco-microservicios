package cl.prestabanco.loans_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoansServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoansServerApplication.class, args);
	}

}
