package cl.prestabanco.evaluations_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvaluationsServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
