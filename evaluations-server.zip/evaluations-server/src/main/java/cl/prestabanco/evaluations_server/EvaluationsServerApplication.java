package cl.prestabanco.evaluations_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluationsServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvaluationsServerApplication.class, args);
	}

}
