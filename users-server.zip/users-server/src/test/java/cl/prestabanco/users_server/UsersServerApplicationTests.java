package cl.prestabanco.users_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
