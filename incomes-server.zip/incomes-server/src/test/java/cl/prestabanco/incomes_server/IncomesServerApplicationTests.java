package cl.prestabanco.incomes_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncomesServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
