package cl.prestabanco.incomes_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IncomesServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(IncomesServerApplication.class, args);
	}

}
